import Dashboard from "views/Dashboard.js";
import Distributors from "views/Distributors";
import Notifications from "views/Notifications.js";
import UserProfile from "views/UserProfile.js";
import SignIn from "views/SignIn.js";
import SignUp from "views/SignUp";
import ForgetPassword from "views/ForgotPassword";
import ResetPassword from "views/ResetPassword";
import Products from "views/Products";

import {
  MdOutlineDashboard,
  MdOutlineSell,
  MdOutlinePointOfSale,
} from "react-icons/md";
import { LiaProductHunt } from "react-icons/lia";
import { BsDistributeHorizontal } from "react-icons/bs";
import { GiBuyCard, GiExpense } from "react-icons/gi";
import BuyOrders from "views/BuyOrders";
import SellOrders from "views/SellOrders";
import Sales from "views/Sales";
import Expenses from "views/Expenses";

var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: <MdOutlineDashboard size={20} />,
    component: <Dashboard />,
    layout: "/admin",
  },
  {
    path: "/products",
    name: "Products",
    icon: <LiaProductHunt size={20} />,
    component: <Products />,
    layout: "/admin",
  },
  {
    path: "/distributors",
    name: "Distributors",
    icon: <BsDistributeHorizontal size={20} />,
    component: <Distributors />,
    layout: "/admin",
  },
  {
    path: "/buy-orders",
    name: "Buy Orders",
    icon: <GiBuyCard size={20} />,
    component: <BuyOrders />,
    layout: "/admin",
  },
  {
    path: "/sell-orders",
    name: "Sell Orders",
    icon: <MdOutlineSell size={20} />,
    component: <SellOrders />,
    layout: "/admin",
  },
  {
    path: "/sales",
    name: "Sales",
    icon: <MdOutlinePointOfSale size={20} />,
    component: <Sales />,
    layout: "/admin",
  },
  {
    path: "/expenses",
    name: "Expense",
    icon: <GiExpense size={20} />,
    component: <Expenses />,
    layout: "/admin",
  },
  {
    path: "/user-profile",
    name: "User Profile",
    icon: "",
    component: <UserProfile />,
    layout: "/admin",
  },
  {
    path: "/notifications",
    name: "Notifications",
    icon: "",
    component: <Notifications />,
    layout: "/admin",
  },
  {
    path: "/login",
    name: "Sign In",
    icon: "",
    component: <SignIn />,
    layout: "/auth",
  },
  {
    path: "/register",
    name: "Sign Up",
    icon: "",
    component: <SignUp />,
    layout: "/auth",
  },
  {
    path: "/forgot-password",
    name: "Forgot Password",
    icon: "",
    component: <ForgetPassword />,
    layout: "/auth",
  },
  {
    path: "/reset-password",
    name: "Reset Password",
    icon: "",
    component: <ResetPassword />,
    layout: "/auth",
  },
];
export default routes;
