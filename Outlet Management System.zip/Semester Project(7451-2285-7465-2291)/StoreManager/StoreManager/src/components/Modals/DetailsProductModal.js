import React from "react";
import { Modal, ModalHeader, ModalBody } from "reactstrap";

function DetailsProductModal({ isOpen, toggle, product }) {
  return (
    <Modal
      isOpen={isOpen}
      toggle={toggle}
      style={{
        top: "45%",
        transform: "translate(0, -50%)",
      }}
    >
      <ModalHeader toggle={toggle}>Product Details</ModalHeader>
      <ModalBody>
        <div className="detail-item">
          <strong>Name:</strong> {product?.name}
        </div>
        <div className="detail-item">
          <strong>Type:</strong> {product?.type}
        </div>
        <div className="detail-item">
          <strong>Brand:</strong> {product?.brand}
        </div>
        <div className="detail-item">
          <strong>Size:</strong> {product?.size}
        </div>
        <div className="detail-item">
          <strong>Price:</strong> {product?.salePrice}
        </div>
        <div className="detail-item">
          <strong>Quantity:</strong> {product?.quantity}
        </div>
        <div className="detail-item">
          <strong>New Purchase Price:</strong> {product?.newPurchasePrice}
        </div>
        <div className="detail-item">
          <strong>Old Purchase Price:</strong> {product?.oldPurchasePrice}
        </div>
        <div className="detail-item">
          <strong>Owned By:</strong> {product?.Shop?.name}
        </div>
      </ModalBody>
    </Modal>
  );
}

export default DetailsProductModal;
