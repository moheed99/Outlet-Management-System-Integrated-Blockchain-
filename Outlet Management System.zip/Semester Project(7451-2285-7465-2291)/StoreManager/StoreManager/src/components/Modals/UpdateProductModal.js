import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Spinner,
} from "reactstrap";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ProductService from "services/product-service";

const ProductTypeEnum = {
  Electric: "Electric",
  Sanitary: "Sanitary",
  Paint: "Paint",
  Hardware: "Hardware",
  Mobile: "Mobile",
  Other: "Other",
};

function UpdateProductModal({ isOpen, toggle, product }) {
  const [updatedProduct, setUpdatedProduct] = useState({});
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const allowedFields = useMemo(
    () => [
      "id",
      "name",
      "type",
      "quantity",
      "oldPurchasePrice",
      "newPurchasePrice",
      "salePrice",
      "size",
      "brand",
    ],
    []
  );

  const filterProductFields = useCallback(
    (product) =>
      allowedFields.reduce((filtered, field) => {
        if (product[field] !== undefined) {
          filtered[field] = product[field];
        }
        return filtered;
      }, {}),
    [allowedFields]
  );

  useEffect(() => {
    if (product) {
      setUpdatedProduct(filterProductFields(product));
    }
  }, [product, filterProductFields]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdatedProduct({ ...updatedProduct, [name]: value });
  };

  const validateFields = () => {
    const newErrors = {};
    if (!updatedProduct.name?.trim()) newErrors.name = "Name is required.";
    if (!updatedProduct.type?.trim()) newErrors.type = "Type is required.";
    if (
      !updatedProduct.quantity ||
      isNaN(updatedProduct.quantity) ||
      Number(updatedProduct.quantity) <= 0
    ) {
      newErrors.quantity = "Quantity must be a valid number greater than 0.";
    }
    if (
      !updatedProduct.oldPurchasePrice ||
      isNaN(updatedProduct.oldPurchasePrice) ||
      Number(updatedProduct.oldPurchasePrice) <= 0
    ) {
      newErrors.oldPurchasePrice =
        "Old Purchase Price must be a valid number greater than 0.";
    }
    if (
      !updatedProduct.newPurchasePrice ||
      isNaN(updatedProduct.newPurchasePrice) ||
      Number(updatedProduct.newPurchasePrice) <= 0
    ) {
      newErrors.newPurchasePrice =
        "New Purchase Price must be a valid number greater than 0.";
    }
    if (
      !updatedProduct.salePrice ||
      isNaN(updatedProduct.salePrice) ||
      Number(updatedProduct.salePrice) <= 0
    ) {
      newErrors.salePrice = "Sale Price must be a valid number greater than 0.";
    }
    if (!updatedProduct.size?.trim()) newErrors.size = "Size is required.";
    if (!updatedProduct.brand?.trim()) newErrors.brand = "Brand is required.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleUpdate = async () => {
    if (!validateFields()) return;
    setLoading(true);
    try {
      let response = await ProductService.update(updatedProduct);
      console.log(response);

      if (response?.success) {
        toast.success(response?.message);
        toggle(); // Close the modal
      } else {
        toast.error(response?.message);
      }
    } catch (error) {
      console.log("Error updating product:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      toggle={toggle}
      style={{
        top: "45%",
        transform: "translate(0, -50%)",
      }}
    >
      <ModalHeader toggle={toggle}>Update Product</ModalHeader>
      <ModalBody>
        <Form>
          <FormGroup>
            <Label>Name</Label>
            <Input
              name="name"
              value={updatedProduct.name || ""}
              onChange={handleInputChange}
              style={{ color: "black" }}
              invalid={!!errors.name}
            />
            {errors.name && <div className="text-danger">{errors.name}</div>}
          </FormGroup>
          <FormGroup>
            <Label>Type</Label>
            <Input
              type="select"
              name="type"
              value={updatedProduct.type || ""}
              onChange={handleInputChange}
              style={{ color: "black" }}
              invalid={!!errors.type}
            >
              <option value="">Select Type</option>
              {Object.values(ProductTypeEnum).map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </Input>
            {errors.type && <div className="text-danger">{errors.type}</div>}
          </FormGroup>
          <div className="d-flex justify-content-around">
            <FormGroup
              className="flex-grow-1 me-2"
              style={{ marginRight: "16px" }}
            >
              <Label>Quantity</Label>
              <Input
                name="quantity"
                type="number"
                value={updatedProduct.quantity || ""}
                onChange={handleInputChange}
                style={{ color: "black" }}
                invalid={!!errors.quantity}
              />
              {errors.quantity && (
                <div className="text-danger">{errors.quantity}</div>
              )}
            </FormGroup>
            <FormGroup className="flex-grow-1">
              <Label>Brand</Label>
              <Input
                name="brand"
                value={updatedProduct.brand || ""}
                onChange={handleInputChange}
                style={{ color: "black" }}
                invalid={!!errors.brand}
              />
              {errors.brand && (
                <div className="text-danger">{errors.brand}</div>
              )}
            </FormGroup>
          </div>
          <div className="d-flex justify-content-around">
            <FormGroup
              className="flex-grow-1 me-2"
              style={{ marginRight: "16px" }}
            >
              <Label>Old Purchase Price</Label>
              <Input
                name="oldPurchasePrice"
                type="number"
                value={updatedProduct.oldPurchasePrice || ""}
                onChange={handleInputChange}
                style={{ color: "black" }}
                invalid={!!errors.oldPurchasePrice}
              />
              {errors.oldPurchasePrice && (
                <div className="text-danger">{errors.oldPurchasePrice}</div>
              )}
            </FormGroup>
            <FormGroup className="flex-grow-1">
              <Label>New Purchase Price</Label>
              <Input
                name="newPurchasePrice"
                type="number"
                value={updatedProduct.newPurchasePrice || ""}
                onChange={handleInputChange}
                style={{ color: "black" }}
                invalid={!!errors.newPurchasePrice}
              />
              {errors.newPurchasePrice && (
                <div className="text-danger">{errors.newPurchasePrice}</div>
              )}
            </FormGroup>
          </div>
          <div className="d-flex justify-content-around">
            <FormGroup
              className="flex-grow-1 me-2"
              style={{ marginRight: "16px" }}
            >
              <Label>Sale Price</Label>
              <Input
                name="salePrice"
                type="number"
                value={updatedProduct.salePrice || ""}
                onChange={handleInputChange}
                style={{ color: "black" }}
                invalid={!!errors.salePrice}
              />
              {errors.salePrice && (
                <div className="text-danger">{errors.salePrice}</div>
              )}
            </FormGroup>
            <FormGroup className="flex-grow-1">
              <Label>Size</Label>
              <Input
                name="size"
                value={updatedProduct.size || ""}
                onChange={handleInputChange}
                style={{ color: "black" }}
                invalid={!!errors.size}
              />
              {errors.size && <div className="text-danger">{errors.size}</div>}
            </FormGroup>
          </div>
        </Form>
      </ModalBody>
      <ModalFooter
        className="justify-content-around"
        style={{ marginBottom: "10px" }}
      >
        <Button color="primary" onClick={handleUpdate} disabled={loading}>
          {loading ? <Spinner size="sm" /> : "Update"}
        </Button>
        <Button color="secondary" onClick={toggle} disabled={loading}>
          Cancel
        </Button>
      </ModalFooter>
    </Modal>
  );
}

export default UpdateProductModal;
