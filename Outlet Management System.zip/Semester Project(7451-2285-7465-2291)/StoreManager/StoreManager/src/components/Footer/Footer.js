import React from "react";

import { Container, Nav, NavItem, NavLink } from "reactstrap";

function Footer() {
  return (
    <footer className="footer" style={{ paddingTop: 0 }}>
      <Container fluid>
        <Nav>
          <NavItem>
            <NavLink href="">Facebook</NavLink>
          </NavItem>
          <NavItem>
            <NavLink href="">Instagram</NavLink>
          </NavItem>
        </Nav>
        <div className="copyright">
          © {new Date().getFullYear()} made by Abdullah
        </div>
      </Container>
    </footer>
  );
}

export default Footer;
