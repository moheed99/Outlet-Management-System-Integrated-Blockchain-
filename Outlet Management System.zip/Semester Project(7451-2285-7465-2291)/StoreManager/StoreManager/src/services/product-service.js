import HttpService from "./htttp.service";

class ProductService {
  authEndpoint = "shop/product/";

  list = async (keyword, pageNo, perPage, filters) => {
    const listEndpoint =
      this.authEndpoint +
      `list?keyword=${keyword}&type=${filters.type}&quantity=${filters.quantity}&brand=${filters.brand}&size=${filters.size}&pageNo=${pageNo}&perPage=${perPage}`;
    return await HttpService.get(listEndpoint);
  };

  save = async (payload) => {
    const saveEndpoint = this.authEndpoint + "save";
    return await HttpService.post(saveEndpoint, payload);
  };

  update = async (payload) => {
    const updateEndpoint = this.authEndpoint + "update";
    return await HttpService.post(updateEndpoint, payload);
  };

  detail = async (productId) => {
    const detailEndpoint = this.authEndpoint + `detail?id=${productId}`;
    return await HttpService.get(detailEndpoint);
  };

  delete = async (payload) => {
    const deleteEndpoint = this.authEndpoint + "delete";
    return await HttpService.post(deleteEndpoint, payload);
  };
}
const productService = new ProductService();
export default productService;
