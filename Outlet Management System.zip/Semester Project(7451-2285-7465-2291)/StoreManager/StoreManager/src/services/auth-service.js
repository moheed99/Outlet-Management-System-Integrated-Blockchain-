import HttpService from "./htttp.service";

class AuthService {
  authEndpoint = "public/";

  login = async (payload) => {
    const loginEndpoint = this.authEndpoint + "login";
    return await HttpService.post(loginEndpoint, payload);
  };

  register = async (credentials) => {
    const registerEndpoint = this.authEndpoint + "register";
    return await HttpService.post(registerEndpoint, credentials);
  };

  forgotPassword = async (payload) => {
    const forgotEndpoint = this.authEndpoint + "forgot-password";
    return await HttpService.post(forgotEndpoint, payload);
  };

  resetPassword = async (credentials) => {
    const resetEndpoint = this.authEndpoint + "reset-password";
    return await HttpService.post(resetEndpoint, credentials);
  };
}
const authService = new AuthService();
export default authService;
