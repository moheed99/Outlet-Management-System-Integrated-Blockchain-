import HttpService from "./htttp.service";

class ProfileService {
  authEndpoint = "shop/profile/";

  update = async (payload) => {
    const updateEndpoint = this.authEndpoint + "update";
    return await HttpService.post(updateEndpoint, payload);
  };
}

export default new ProfileService();
