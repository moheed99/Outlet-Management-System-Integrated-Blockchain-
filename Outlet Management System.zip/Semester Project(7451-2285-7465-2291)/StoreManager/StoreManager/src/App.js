// src/frontend/App.js
import React, { useState, useContext } from "react";
import axios from "axios";
import { Routes, Route, Navigate } from "react-router-dom";
import { AuthContext } from "contexts/AuthContext";
import AdminLayout from "layouts/Admin/Admin.js";
import AuthLayout from "layouts/Auth/Auth.js";

// Import blockchain interaction
import { web3, contract } from "./blockchain";  // Blockchain interaction

export default function App() {
  const { isAuthenticated } = useContext(AuthContext);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [itemIndex, setItemIndex] = useState("");
  const [item, setItem] = useState(null);

  // Function to add item to the blockchain
  const handleAddItem = async () => {
    try {
      // First, send the request to backend to record the item
      await axios.post("http://localhost:5000/api/addItem", { name, price });

      // After adding to backend, interact with blockchain to confirm (optional)
      const accounts = await web3.eth.getAccounts();
      await contract.methods.recordTransaction(Date.now(), name, price, accounts[0]).send({ from: accounts[0] });

      alert("Item added to blockchain!");
      setName("");
      setPrice("");
    } catch (error) {
      // Improved error handling
      let errorMessage = "An error occurred!";  // Default message if no detailed error is available
      if (error.response) {
        // Backend error response
        errorMessage = error.response?.data?.error || error.response?.data?.message || "Something went wrong!";
      } else if (error.message) {
        // Error from Axios or Web3
        errorMessage = error.message || "Failed to connect to the server.";
      }
      console.error("Error adding item:", errorMessage);
      alert(errorMessage);  // Display the error message to the user
    }
  };

  // Function to fetch item from blockchain
  const handleGetItem = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/getItem/${itemIndex}`);
      setItem(response.data);  // Set the fetched item data
    } catch (error) {
      // Improved error handling
      let errorMessage = "An error occurred!";  // Default message if no detailed error is available
      if (error.response) {
        // Backend error response
        errorMessage = error.response?.data?.error || error.response?.data?.message || "Something went wrong!";
      } else if (error.message) {
        // Error from Axios or Web3
        errorMessage = error.message || "Failed to connect to the server.";
      }
      console.error("Error fetching item:", errorMessage);
      alert(errorMessage);  // Display the error message to the user
    }
  };

  return (
    <Routes>
      {isAuthenticated ? (
        <Route path="/admin/*" element={<AdminLayout />} />
      ) : (
        <Route path="/auth/*" element={<AuthLayout />} />
      )}

      {/* Redirect any other paths */}
      <Route path="*" element={<Navigate to={isAuthenticated ? "/admin/dashboard" : "/auth/login"} replace />} />

      {/* Form to add item */}
      <Route
        path="/add-item"
        element={
          <div>
            <h2>Add Item to Blockchain</h2>
            <input
              type="text"
              placeholder="Item Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <input
              type="number"
              placeholder="Item Price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
            <button onClick={handleAddItem}>Add Item</button>
          </div>
        }
      />

      {/* Form to get item */}
      <Route
        path="/get-item"
        element={
          <div>
            <h2>Get Item from Blockchain</h2>
            <input
              type="number"
              placeholder="Item Index"
              value={itemIndex}
              onChange={(e) => setItemIndex(e.target.value)}
            />
            <button onClick={handleGetItem}>Get Item</button>
            {item && (
              <div>
                <h3>Item Details:</h3>
                <p>Name: {item.name}</p>
                <p>Price: {item.price}</p>
              </div>
            )}
          </div>
        }
      />
    </Routes>
  );
}
