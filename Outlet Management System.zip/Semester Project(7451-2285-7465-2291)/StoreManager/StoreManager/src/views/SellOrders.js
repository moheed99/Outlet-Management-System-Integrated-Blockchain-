import React, { useState } from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash, FaInfoCircle } from "react-icons/fa"; // Importing icons

function SellOrders() {
  const [searchTerm, setSearchTerm] = useState("");

  const sellorders = [
    {
      orderId: 101,
      customerName: "John Doe",
      customerPhone: "555-0123",
      price: 250.0,
      paymentStatus: "Paid",
      status: "Shipped",
      date: "2024-01-15",
      amountPaid: 250.0,
      amountPending: 0.0,
    },
    {
      orderId: 102,
      customerName: "Jane Smith",
      customerPhone: "555-0456",
      price: 180.5,
      paymentStatus: "Pending",
      status: "Processing",
      date: "2024-02-10",
      amountPaid: 0.0,
      amountPending: 180.5,
    },
    {
      orderId: 103,
      customerName: "Alice Johnson",
      customerPhone: "555-0789",
      price: 320.75,
      paymentStatus: "Paid",
      status: "Delivered",
      date: "2024-03-20",
      amountPaid: 320.75,
      amountPending: 0.0,
    },
    {
      orderId: 104,
      customerName: "Bob Brown",
      customerPhone: "555-1011",
      price: 150.0,
      paymentStatus: "Pending",
      status: "Cancelled",
      date: "2024-04-05",
      amountPaid: 0.0,
      amountPending: 150.0,
    },
    {
      orderId: 105,
      customerName: "Chris Green",
      customerPhone: "555-1213",
      price: 75.25,
      paymentStatus: "Paid",
      status: "Shipped",
      date: "2024-05-12",
      amountPaid: 75.25,
      amountPending: 0.0,
    },
    {
      orderId: 106,
      customerName: "Diana White",
      customerPhone: "555-1415",
      price: 200.0,
      paymentStatus: "Pending",
      status: "Processing",
      date: "2024-06-30",
      amountPaid: 0.0,
      amountPending: 200.0,
    },
    {
      orderId: 107,
      customerName: "Evan Black",
      customerPhone: "555-1617",
      price: 89.99,
      paymentStatus: "Paid",
      status: "Delivered",
      date: "2024-07-18",
      amountPaid: 89.99,
      amountPending: 0.0,
    },
  ];

  // Function to handle search
  const filteredSellOrders = sellorders.filter((order) =>
    order.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <Row>
                <Col md="8">
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ marginBottom: "10px" }}
                  />
                </Col>
                <Col md="4" className="text-right">
                  <Button color="primary">
                    <FaPlus />
                  </Button>
                </Col>
              </Row>
            </CardHeader>
            <CardBody>
              <Table className="tablesorter" responsive>
                <thead className="text-primary">
                  <tr>
                    <th className="text-center">OrderId</th>
                    <th className="text-center">Customer</th>
                    <th className="text-center">Phone</th>
                    <th className="text-center">Price</th>
                    <th className="text-center">Paid</th>
                    <th className="text-center">Pending</th>
                    <th className="text-center">Payment Status</th>
                    <th className="text-center">Status</th>
                    <th className="text-center">Date</th>
                    <th className="text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSellOrders.map((order, index) => (
                    <tr key={index}>
                      <td className="text-center">{order.orderId}</td>
                      <td className="text-center">{order.customerName}</td>
                      <td className="text-center">{order.customerPhone}</td>
                      <td className="text-center">{order.price}</td>
                      <td className="text-center">{order.amountPaid}</td>
                      <td className="text-center">{order.amountPending}</td>
                      <td className="text-center">{order.paymentStatus}</td>
                      <td className="text-center">{order.status}</td>
                      <td className="text-center">{order.date}</td>
                      <td className="text-center">
                        <Button color="warning" size="sm" className="mr-2">
                          <FaInfoCircle />
                        </Button>
                        <Button color="warning" size="sm" className="mr-2">
                          <FaEdit />
                        </Button>
                        <Button color="danger" size="sm">
                          <FaTrash />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default SellOrders;
