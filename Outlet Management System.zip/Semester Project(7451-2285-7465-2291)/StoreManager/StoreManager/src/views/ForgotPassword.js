import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
  Spinner,
  Alert,
} from "reactstrap";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AuthService from "services/auth-service";

function ForgetPassword() {
  const navigate = useNavigate();

  // States
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Handle email input change
  const handleInputChange = (e) => {
    setEmail(e.target.value);
  };

  // Handle the forgot password functionality
  const handleForgot = async () => {
    // Validate email
    if (!email) {
      setError("Email is required.");
      return;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }

    setError(""); // Clear errors
    setLoading(true); // Show loader

    try {
      // Simulate login logic or call an API
      let response = await AuthService.forgotPassword({
        email: email,
      }); // Assume `login` is an async function
      console.log(response);

      if (response?.success) {
        toast.success(response?.message);
        // Navigate to reset password on success
        navigate("/auth/reset-password");
      } else {
        toast.error(response?.message);
      }
    } catch (err) {
      // Handle failure (e.g., network or server error)
      console.log("Forgot Password Error.");
    } finally {
      setLoading(false); // Hide loader
    }
  };

  return (
    <div className="container">
      <Row className="vh-100 align-items-center justify-content-center">
        <Col md="4">
          <Card className="card-user">
            <CardBody>
              <CardText />
              <div className="author">
                <div className="block block-one" />
                <div className="block block-two" />
                <div className="block block-three" />
                <div className="block block-four" />
                <a href="#pablo" onClick={(e) => e.preventDefault()}>
                  <h3 className="title">Forgot Password</h3>
                </a>
                <p className="card-description">Enter the registered email</p>
              </div>
              <Form style={{ marginTop: 30 }}>
                <Row>
                  <Col md="12">
                    <FormGroup>
                      <label>Email</label>
                      <Input
                        value={email}
                        onChange={handleInputChange}
                        placeholder="Enter Email"
                        type="email"
                      />
                      {error && <Alert color="danger">{error}</Alert>}
                    </FormGroup>
                  </Col>
                </Row>
              </Form>
            </CardBody>
            <CardFooter
              className="card-footer d-flex flex-column align-items-center"
              style={{ paddingTop: 0 }}
            >
              <Button
                className="btn-fill"
                color="primary"
                type="button"
                style={{ width: "100%", marginBottom: "10px", marginTop: 0 }}
                onClick={handleForgot}
                disabled={loading} // Disable button while loading
              >
                {loading ? <Spinner size="sm" /> : "Continue"}
              </Button>
              <div
                className="text-center mb-2"
                style={{
                  fontSize: "0.8rem",
                  paddingTop: 5,
                  paddingBottom: 5,
                }}
              >
                <span>
                  Go back to?{" "}
                  <a
                    href="#reset"
                    onClick={() => navigate("/auth/login")}
                    style={{ color: "#e14eca", textDecoration: "underline" }}
                  >
                    Sign In
                  </a>
                </span>
              </div>
            </CardFooter>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default ForgetPassword;
