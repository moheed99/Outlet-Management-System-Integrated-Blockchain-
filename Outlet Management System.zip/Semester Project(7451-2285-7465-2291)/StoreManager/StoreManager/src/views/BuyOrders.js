import React, { useState } from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash, FaInfoCircle } from "react-icons/fa"; // Importing icons

function BuyOrders() {
  const [searchTerm, setSearchTerm] = useState("");

  const buyorders = [
    {
      orderId: 1,
      distributorName: "Distributor 1",
      date: "2024-01-15",
      price: 5000,
      status: "Shipped",
    },
    {
      orderId: 2,
      distributorName: "Distributor 2",
      date: "2024-02-10",
      price: 7500,
      status: "Pending",
    },
    {
      orderId: 3,
      distributorName: "Distributor 3",
      date: "2024-03-20",
      price: 12000,
      status: "Delivered",
    },
    {
      orderId: 4,
      distributorName: "Distributor 4",
      date: "2024-04-05",
      price: 3000,
      status: "Cancelled",
    },
    {
      orderId: 5,
      distributorName: "Distributor 5",
      date: "2024-05-12",
      price: 15000,
      status: "Shipped",
    },
    {
      orderId: 6,
      distributorName: "Distributor 6",
      date: "2024-06-30",
      price: 4000,
      status: "Pending",
    },
    {
      orderId: 7,
      distributorName: "Distributor 7",
      date: "2024-07-18",
      price: 8000,
      status: "Delivered",
    },
  ];

  // Function to handle search
  const filteredBuyOrders = buyorders.filter((order) =>
    order.distributorName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <Row>
                <Col md="8">
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ marginBottom: "10px" }}
                  />
                </Col>
                <Col md="4" className="text-right">
                  <Button color="primary">
                    <FaPlus />
                  </Button>
                </Col>
              </Row>
            </CardHeader>
            <CardBody>
              <Table className="tablesorter" responsive>
                <thead className="text-primary">
                  <tr>
                    <th className="text-center">ORDERID</th>
                    <th className="text-center">Distributor</th>
                    <th className="text-center">Price</th>
                    <th className="text-center">Date</th>
                    <th className="text-center">Status</th>
                    <th className="text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBuyOrders.map((order, index) => (
                    <tr key={index}>
                      <td className="text-center">{order.orderId}</td>
                      <td className="text-center">{order.distributorName}</td>
                      <td className="text-center">{order.price}</td>
                      <td className="text-center">{order.date}</td>
                      <td className="text-center">{order.status}</td>
                      <td className="text-center">
                        <Button color="warning" size="sm" className="mr-2">
                          <FaInfoCircle />
                        </Button>
                        <Button color="warning" size="sm" className="mr-2">
                          <FaEdit />
                        </Button>
                        <Button color="danger" size="sm">
                          <FaTrash />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default BuyOrders;
