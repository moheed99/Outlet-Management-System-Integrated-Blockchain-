import { AuthContext } from "contexts/AuthContext";
import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";

// reactstrap components
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
  Spinner,
  Alert,
} from "reactstrap";
import AuthService from "services/auth-service";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function SignIn() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false); // For loader state

  const handleLogin = async () => {
    // Basic validation
    if (!email || !password) {
      setError("Email and Password are required.");
      return;
    }

    setError(""); // Clear any existing errors
    setLoading(true); // Show loader while waiting for the response

    try {
      // Simulate login logic or call an API
      let response = await AuthService.login({
        email: email,
        password: password,
      }); // Assume `login` is an async function

      if (response?.success) {
        toast.success(response?.message);
        let data = response?.data;
        login(data?.token);
      } else {
        toast.error(response?.message);
      }
    } catch (err) {
      console.log("SignIn Error.");
    } finally {
      setLoading(false); // Hide loader after response
    }
  };

  const navigateTo = (path) => {
    navigate(path);
  };

  return (
    <>
      <div className="container">
        <Row className="vh-100 align-items-center justify-content-center">
          <Col md="4">
            <Card className="card-user">
              <CardBody>
                <CardText />
                <div className="author">
                  <div className="block block-one" />
                  <div className="block block-two" />
                  <div className="block block-three" />
                  <div className="block block-four" />
                  <a href="#pablo" onClick={(e) => e.preventDefault()}>
                    <h3 className="title">Welcome</h3>
                  </a>
                  <p className="card-description">
                    Enter the following credentials
                  </p>
                </div>
                <Form style={{ marginTop: 30 }}>
                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Email</label>
                        <Input
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="Enter Email"
                          type="email"
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Password</label>
                        <Input
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Enter Password"
                          type="password"
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  {error && <Alert color="danger">{error}</Alert>}
                </Form>
              </CardBody>
              <CardFooter
                className="card-footer d-flex flex-column align-items-center"
                style={{ paddingTop: 0 }}
              >
                <Button
                  className="btn-fill"
                  color="primary"
                  type="submit"
                  style={{ width: "100%", marginBottom: "10px", marginTop: 0 }}
                  onClick={handleLogin}
                  disabled={loading} // Disable button while loading
                >
                  {loading ? <Spinner size="sm" /> : "Sign In"}
                </Button>
                <div
                  className="text-center mb-2"
                  style={{
                    fontSize: "0.8rem",
                    paddingTop: 5,
                    paddingBottom: 5,
                  }}
                >
                  <span>
                    Forgot your password?{" "}
                    <a
                      href="#reset"
                      onClick={() => {
                        navigateTo("/auth/forgot-password");
                      }}
                      style={{
                        color: "#e14eca",
                        textDecoration: "underline",
                        cursor: "pointer",
                      }}
                    >
                      Reset here
                    </a>
                  </span>
                </div>
                <div
                  className="text-center"
                  style={{ fontSize: "0.7rem", paddingBottom: 5 }}
                >
                  <span>
                    Already have an account?{" "}
                    <a
                      href="#signup"
                      onClick={() => {
                        navigateTo("/auth/register");
                      }}
                      style={{
                        color: "#e14eca",
                        textDecoration: "underline",
                        cursor: "pointer",
                      }}
                    >
                      Sign up
                    </a>
                  </span>
                </div>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default SignIn;
