import React, { useState } from "react";

// reactstrap components
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
  Spinner,
  Alert,
} from "reactstrap";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AuthService from "services/auth-service";

function SignUp() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phoneNumber: "",
    password: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateFields = () => {
    const { name, email, phoneNumber, password } = formData;
    if (!name || !email || !phoneNumber || !password) {
      setError("All fields are required.");
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Invalid email format.");
      return false;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return false;
    }
    setError("");
    return true;
  };

  const handleRegister = async () => {
    if (!validateFields()) return;

    setIsLoading(true);

    try {
      let response = await AuthService.register(formData);
      console.log(response);

      if (response?.success) {
        toast.success(response?.message);
        navigateTo("/auth/login");
      } else {
        toast.error(response?.message);
      }
    } catch (err) {
      console.log("Signup Error.");
    } finally {
      setIsLoading(false);
    }
  };

  const navigateTo = (path) => {
    navigate(path);
  };

  return (
    <div className="container">
      <Row className="vh-100 align-items-center justify-content-center">
        <Col md="4">
          <Card className="card-user">
            <CardBody>
              <CardText />
              <div className="author">
                <a href="#pablo" onClick={(e) => e.preventDefault()}>
                  <h3 className="title">Welcome</h3>
                </a>
                <p className="card-description">
                  Please fill the following and submit
                </p>
              </div>
              <Form style={{ marginTop: 30 }}>
                <Row>
                  <Col sm="12">
                    <FormGroup>
                      <label>Name</label>
                      <Input
                        name="name"
                        value={formData.name}
                        placeholder="Enter Name"
                        type="text"
                        onChange={handleInputChange}
                      />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col sm="12">
                    <FormGroup>
                      <label>Email</label>
                      <Input
                        name="email"
                        value={formData.email}
                        placeholder="Enter Email"
                        type="email"
                        onChange={handleInputChange}
                      />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col sm="12">
                    <FormGroup>
                      <label>Phone</label>
                      <Input
                        name="phoneNumber"
                        value={formData.phone}
                        placeholder="Enter Phone Number"
                        type="text"
                        onChange={handleInputChange}
                      />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col sm="12">
                    <FormGroup>
                      <label>Password</label>
                      <Input
                        name="password"
                        value={formData.password}
                        placeholder="Enter Password"
                        type="password"
                        onChange={handleInputChange}
                      />
                    </FormGroup>
                  </Col>
                </Row>
              </Form>
              {error && <Alert color="danger">{error}</Alert>}
            </CardBody>
            <CardFooter
              className="card-footer d-flex flex-column align-items-center"
              style={{ paddingTop: 0 }}
            >
              <Button
                className="btn-fill"
                color="primary"
                type="button"
                style={{ width: "100%", marginBottom: "10px", marginTop: 0 }}
                onClick={handleRegister}
                disabled={isLoading}
              >
                {isLoading ? <Spinner size="sm" /> : "Sign Up"}
              </Button>

              <div
                className="text-center"
                style={{ fontSize: "0.7rem", paddingBottom: 5 }}
              >
                <span>
                  Already have an account?{" "}
                  <a
                    href="#SignIn"
                    onClick={() => {
                      navigateTo("/auth/login");
                    }}
                    style={{
                      color: "#e14eca",
                      textDecoration: "underline",
                      cursor: "pointer",
                    }}
                  >
                    Sign In
                  </a>
                </span>
              </div>
            </CardFooter>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default SignUp;
