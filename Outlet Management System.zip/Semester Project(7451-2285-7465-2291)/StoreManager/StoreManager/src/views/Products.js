import React, { useState, useEffect, useCallback } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
  Pagination,
  PaginationItem,
  PaginationLink,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Spinner,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash, FaInfoCircle } from "react-icons/fa";
import AddProductModal from "../components/Modals/AddProductModal";
import UpdateProductModal from "../components/Modals/UpdateProductModal";
import DetailsProductModal from "../components/Modals/DetailsProductModal";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ProductService from "services/product-service";

const ProductTypeEnum = {
  Electric: "Electric",
  Sanitary: "Sanitary",
  Paint: "Paint",
  Hardware: "Hardware",
  Mobile: "Mobile",
  Other: "Other",
};

function Products() {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 7;
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [deleteProduct, setDeleteProduct] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalPages, setTotalPages] = useState(1);

  // New state for filters
  const [filters, setFilters] = useState({
    type: "",
    brand: "",
    size: "",
    quantity: "",
  });

  // Fetch products from API with filters
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      let response = await ProductService.list(
        searchTerm,
        currentPage,
        itemsPerPage,
        filters
      );
      if (response?.success) {
        if (response?.data) {
          response?.data?.rows
            ? setProducts(response?.data?.rows)
            : response?.data?.data
            ? setProducts(response?.data?.data)
            : setProducts([]);
          response.data.totalPages > 1
            ? setTotalPages(response.data.totalPages)
            : setTotalPages(1);
        }
      } else {
        toast.error(response?.message);
      }
    } catch (error) {
      console.log("Error fetching products:", error);
    } finally {
      setLoading(false);
    }
  }, [searchTerm, currentPage, filters]);

  useEffect(() => {
    if (!isAddModalOpen && !isUpdateModalOpen) {
      fetchProducts();
    }
  }, [
    searchTerm,
    currentPage,
    filters,
    fetchProducts,
    isAddModalOpen,
    isUpdateModalOpen,
  ]);

  const handleDelete = (product) => setDeleteProduct(product);
  const confirmDelete = async () => {
    setLoading(true);
    try {
      let response = await ProductService.delete({ id: deleteProduct?.id });
      if (response?.success) {
        toast.success(response?.message);
        fetchProducts();
        setDeleteProduct(null);
      } else {
        toast.error(response?.message);
      }
    } catch (error) {
      console.log("Error deleting product:", error);
    } finally {
      setLoading(false);
    }
  };

  // Handle change for filters
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <>
      {/* Add Product Modal */}
      <AddProductModal
        isOpen={isAddModalOpen}
        toggle={() => setIsAddModalOpen(false)}
      />

      {/* Update Product Modal */}
      <UpdateProductModal
        isOpen={isUpdateModalOpen}
        toggle={() => setIsUpdateModalOpen(false)}
        product={selectedProduct}
      />

      {/* Details Product Modal */}
      <DetailsProductModal
        isOpen={isDetailsModalOpen}
        toggle={() => setIsDetailsModalOpen(!isDetailsModalOpen)}
        product={selectedProduct}
      />

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteProduct}
        toggle={() => setDeleteProduct(null)}
        style={{
          top: "45%",
          transform: "translate(0, -50%)",
        }}
      >
        <ModalHeader toggle={() => setDeleteProduct(null)}>
          Confirm Delete
        </ModalHeader>
        <ModalBody>
          Are you sure you want to delete the product:{" "}
          <strong>{deleteProduct?.name}</strong>?
        </ModalBody>
        <ModalFooter
          className="justify-content-around"
          style={{ marginBottom: "10px" }}
        >
          <Button color="danger" onClick={confirmDelete}>
            Delete
          </Button>
          <Button color="secondary" onClick={() => setDeleteProduct(null)}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>

      <div className="content">
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <Row>
                  <Col md="2">
                    <Input
                      type="text"
                      placeholder="Name"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </Col>

                  <Col md="2">
                    <Input
                      type="text"
                      name="brand"
                      placeholder="Brand"
                      value={filters.brand}
                      onChange={handleFilterChange}
                    />
                  </Col>
                  <Col md="2">
                    <Input
                      type="text"
                      name="size"
                      placeholder="Size"
                      value={filters.size}
                      onChange={handleFilterChange}
                    />
                  </Col>
                  <Col md="2">
                    <Input
                      type="number"
                      name="quantity"
                      placeholder="Quantity"
                      value={filters.quantity}
                      onChange={handleFilterChange}
                      min="0"
                    />
                  </Col>
                  <Col md="2">
                    <Input
                      type="select"
                      name="type"
                      value={filters.type}
                      onChange={handleFilterChange}
                    >
                      <option value="">All Types</option>
                      {Object.entries(ProductTypeEnum).map(([key, value]) => (
                        <option key={key} value={value}>
                          {value}
                        </option>
                      ))}
                    </Input>
                  </Col>
                  <Col md="2" className="text-right">
                    <Button
                      color="primary"
                      style={{
                        margin: 0,
                        height: 35,
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                      onClick={() => setIsAddModalOpen(true)}
                    >
                      <FaPlus style={{ verticalAlign: "unset" }} />
                    </Button>
                  </Col>
                </Row>
                {/* Filter Row */}
                <Row className="mt-3"></Row>
              </CardHeader>
              <CardBody>
                {loading ? (
                  <div className="text-center">
                    <Spinner />
                  </div>
                ) : (
                  <Table className="table-content" responsive>
                    <thead>
                      <tr>
                        <th className="text-center">Name</th>
                        <th className="text-center">Type</th>
                        <th className="text-center">Brand</th>
                        <th className="text-center">Size</th>
                        <th className="text-center">Price</th>
                        <th className="text-center">Quantity</th>
                        <th className="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.length > 0 ? (
                        products.map((product, index) => (
                          <tr key={index}>
                            <td className="text-center">{product.name}</td>
                            <td className="text-center">{product.type}</td>
                            <td className="text-center">{product.brand}</td>
                            <td className="text-center">{product.size}</td>
                            <td className="text-center">{product.salePrice}</td>
                            <td className="text-center">{product.quantity}</td>
                            <td className="d-flex flex-direction-row justify-content-center">
                              <Button
                                color="info"
                                size="sm"
                                className="mr-2"
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                }}
                                onClick={() => {
                                  setSelectedProduct(product);
                                  setIsDetailsModalOpen(true);
                                }}
                              >
                                <FaInfoCircle />
                              </Button>
                              <Button
                                color="warning"
                                size="sm"
                                className="mr-2"
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                }}
                                onClick={() => {
                                  setSelectedProduct(product);
                                  setIsUpdateModalOpen(true);
                                }}
                              >
                                <FaEdit />
                              </Button>
                              <Button
                                color="danger"
                                size="sm"
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                }}
                                onClick={() => handleDelete(product)}
                              >
                                <FaTrash />
                              </Button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr style={{ height: 380 }}>
                          <td colSpan="7" className="text-center">
                            No products available.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                )}
                {/* Pagination */}
                {products.length > 0 && (
                  <div className="d-flex justify-content-end ">
                    <Pagination>
                      <PaginationItem disabled={currentPage === 1}>
                        <PaginationLink
                          previous
                          onClick={() => setCurrentPage((prev) => prev - 1)}
                        />
                      </PaginationItem>
                      {[...Array(totalPages)].map((_, index) => (
                        <PaginationItem
                          key={index}
                          active={currentPage === index + 1}
                        >
                          <PaginationLink
                            onClick={() => setCurrentPage(index + 1)}
                          >
                            {index + 1}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      <PaginationItem disabled={currentPage === totalPages}>
                        <PaginationLink
                          next
                          onClick={() => setCurrentPage((prev) => prev + 1)}
                        />
                      </PaginationItem>
                    </Pagination>
                  </div>
                )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default Products;
