const OutletManagement = artifacts.require("OutletManagement");

module.exports = function (deployer) {
    deployer.deploy(OutletManagement);
};
