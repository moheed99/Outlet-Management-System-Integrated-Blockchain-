// src/backend/server.js
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const port = 5000;

// Import routes
const blockchainRoutes = require("./routes/blockchainRoutes");

// Middleware to parse incoming JSON requests
app.use(bodyParser.json());

// Use the blockchain routes for the API calls
app.use(blockchainRoutes);

// Start the Express server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
