import nodemailer from "nodemailer";
import { AuthMiddleware } from "../middlewares/auth.middleware";
import { AppSetupMiddleware } from "../middlewares/app-setup.middleware";

import { Helpers } from "./../common/helpers";
import express from "express";
import http from "http";
import mongoose, { Document } from "mongoose";

import { ShopRoutes } from "../routes/shop-routes";

import { PublicRoutes } from "./../routes/public-routes";

import { sequelize } from "../configs/connection";

import { filePath } from "../helpers/helper";

import ngrok from "@ngrok/ngrok";

require("dotenv").config({ path: filePath("") + "/.env" });

export class App {
    app: express.Application;

    constructor(app: express.Application) {
        this.app = app;
        this.app.set("view engine", "ejs");

        this.app.get("/", async function (req: any, res: any) {
            res.send("----- Store Manager API -----");
        });

        const server: http.Server = http.createServer(this.app);

        this.registerMiddlewares();
        this.registerRoutes();
        this.errorHandling();
        this.startServer(server);
        this.initiateSingletons();
        this.setChalk();
        try {
            //this.syncDB({ alter: true })
        } catch (e) {
            (global as any).log.info("Level");
            (global as any).log.info(e);
        }
    }

    registerRoutes() {
        new ShopRoutes(this.app);

        new PublicRoutes(this.app);
    }

    secureApiRoutes() {
        this.app.use("/api", new AuthMiddleware(this.app).handle);
    }

    registerMiddlewares() {
        const middlewares = new AppSetupMiddleware(this.app);
        middlewares.handle();
    }

    startServer(server: http.Server) {
        const port = Number(process.env.PORT_NO);

        server.listen(port, () => {});
    }

    initiateSingletons() {
        new Helpers(this.app);
    }

    errorHandling() {
        this.app.use(function (req, res, next) {
            res.status(404);

            // respond with html page
            if (req.accepts("html")) {
                res.render("404", { url: req.url });
                return;
            }

            // respond with json
            if (req.accepts("json")) {
                res.Error("Page not found", null, 404);
                return;
            }

            // default to plain-text. send()
            res.type("txt").send("Not found");
        });
    }

    syncDB(options: any) {
        if (process.env.NODE_ENV === "development") {
            (global as any).log.info("Synchronizing MySQL database");
            //modelsImport()

            sequelize
                .sync(options)
                .then((e: any) => {
                    (global as any).log.info("DB Synchronization Complete");
                })
                .catch((e: any) => {
                    (global as any).log.error(e);
                });
        }
    }

    connectMongoDB() {
        const URL: any = process.env.MONGO_DB_HOST;
        var options: any = {
            dbName: process.env.MONGO_DB_NAME,
            user: process.env.MONGO_DB_USERNAME,
            pass: process.env.MONGO_DB_PASSWORD,
        };

        mongoose.connect(URL, options);
    }

    setChalk() {
        (global as any).log = {
            error: (obj: any) => {
                obj = obj instanceof Object ? JSON.stringify(obj) : obj;
            },
            info: (obj: any) => {
                obj = obj instanceof Object ? JSON.stringify(obj) : obj;
            },
            success: (obj: any) => {
                obj = obj instanceof Object ? JSON.stringify(obj) : obj;
            },
        };
    }
}

export const smtptransporter = nodemailer.createTransport({
    host: process.env.MAIL_HOST,
    port: Number(process.env.MAIL_PORT),
    secure: false,
    auth: {
        user: process.env.MAIL_USERNAME,
        pass: process.env.MAIL_PASSWORD,
    },
});
