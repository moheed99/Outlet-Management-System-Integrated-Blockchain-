import express from "express";
import Joi, { ValidationError } from "joi";
import { sequelize } from "../configs/connection";
import { Product } from "../models/product";
import { Op } from "sequelize";
import { Shop } from "../models/shop";
import { paging } from "../helpers/helper";
import { ShopExpense } from "../models/shop-expense";

export class ExpenseController {
    private static instance: ExpenseController | null = null;

    private constructor() {}

    static init(): ExpenseController {
        if (this.instance == null) {
            this.instance = new ExpenseController();
        }

        return this.instance;
    }

    public async add(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            amount: Joi.number().required(),
            title: Joi.string().required(),
            description: Joi.string().optional(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const expenseData = {
            title: req.body.title,
            shopId: req.auth.id,
            amount: req.body.amount,
            description: req.body.description,
            createdAt: new Date(),
            updatedAt: new Date(),
        };

        try {
            const instance = await ShopExpense.create(expenseData);

            res.Success("Added Successfully");
        } catch (e: any) {
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }

    public async update(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
            amount: Joi.number().required(),
            title: Joi.string().required(),
            description: Joi.string().optional(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const shopexpense: ShopExpense = await ShopExpense.findByPk(
            req.body.id
        );

        if (!shopexpense) {
            res.Error("Shop expense with this id does not exist");
            return;
        }

        const expenseData = {
            ...req.body,
            shopId: req.auth.id,
            updatedAt: new Date(),
        };

        try {
            const instance = await ShopExpense.update(expenseData, {
                where: { id: req.body.id, shopId: req.auth.id },
            });

            res.Success("Updated Successfully");
            return;
        } catch (e: any) {
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }

    public async delete(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const result = await ShopExpense.destroy({
            where: { id: req.body.id, shopId: req.auth.id },
        });

        if (result == 0) {
            res.Error("Record not Found");
            return;
        }
        return res.Success("Deleted successfully");
    }

    public async list(req: express.Request, res: express.Response) {
        let qp = req.query;
        let perPage: any = Number(qp.perPage) > 0 ? Number(qp.perPage) : 20;
        let pageNo: any = Number(qp.page) > 0 ? Number(qp.page) - 1 : 0;
        let order: Array<any> = [];
        if (req.query.orderBy && req.query.order) {
            order.push([
                req.query.orderBy as string,
                req.query.order as string,
            ]);
        } else {
            order.push(["createdAt", "DESC"]);
        }

        const where: any = {};

        where["shopId"] = req.auth.id;

        if (qp.keyword) {
            where["title"] = { [Op.like]: "%" + qp.keyword + "%" };
        }

        const data = await ShopExpense.findAndCountAll({
            where,
            distinct: true,
            order,
            offset: perPage * pageNo,
            limit: perPage,
        }).catch((e) => {
            console.log(e);
            return res.Error("Error in fetching list");
        });

        if (qp.hasOwnProperty("page")) {
            return res.Success("list", paging(data, pageNo, perPage));
        } else {
            return res.Success("list", data);
        }
    }

    public async detail(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const where: any = {
            id: Number(req.body.id),
            shopId: Number(req.auth.id),
        };

        const expense = await ShopExpense.findOne({
            where,
        });

        if (expense === null) {
            res.Error("data not found");
            return;
        }

        res.Success("Expense Details", expense);
    }
}
