import express from "express";
import Joi, { ValidationError } from "joi";
import { sequelize } from "../configs/connection";
import { Product } from "../models/product";
import { Op } from "sequelize";
import { Shop } from "../models/shop";
import { paging } from "../helpers/helper";

export class ProductController {
    private static instance: ProductController | null = null;

    private constructor() {}

    static init(): ProductController {
        if (this.instance == null) {
            this.instance = new ProductController();
        }

        return this.instance;
    }

    public async add(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            quantity: Joi.number().required(),
            oldPurchasePrice: Joi.number().required(),
            newPurchasePrice: Joi.number().required(),
            salePrice: Joi.number().required(),
            size: Joi.string().required(),
            brand: Joi.string().required(),
            name: Joi.string().required(),
            type: Joi.string().required(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const checkProduct: Product = await Product.findOne({
            where: {
                name: req.body.name,
                size: req.body.size,
                brand: req.body.brand,
                shopId: req.auth.id,
            },
        });

        if (checkProduct != null) {
            res.Error("Product already added");
            return;
        }

        const productData = {
            name: req.body.name,
            shopId: req.auth.id,
            quantity: req.body.quantity,
            oldPurchasePrice: req.body.oldPurchasePrice,
            newPurchasePrice: req.body.newPurchasePrice,
            salePrice: req.body.salePrice,
            size: req.body.size,
            brand: req.body.brand,
            type: req.body.type,
            createdAt: new Date(),
            updatedAt: new Date(),
        };

        const transaction = await sequelize.transaction();
        try {
            const instance = await Product.create(productData, { transaction });

            await transaction.commit();

            res.Success("Added Successfully");
        } catch (e: any) {
            await transaction.rollback();
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }

    public async update(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
            quantity: Joi.number().required(),
            oldPurchasePrice: Joi.number().required(),
            newPurchasePrice: Joi.number().required(),
            salePrice: Joi.number().required(),
            size: Joi.string().required(),
            brand: Joi.string().required(),
            name: Joi.string().required(),
            type: Joi.string().required(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const product: Product = await Product.findByPk(req.body.id);

        if (!product) {
            res.Error("Product with this id does not exist");
            return;
        }

        const productData = {
            ...req.body,
            updatedAt: new Date(),
        };

        try {
            const instance = await Product.update(productData, {
                where: { id: req.body.id, shopId: req.auth.id },
            });

            res.Success("Updated Successfully");
        } catch (e: any) {
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }
    public async delete(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const result = await Product.destroy({
            where: { id: req.body.id, shopId: req.auth.id },
        });

        if (result == 0) {
            res.Error("Record not Found");
            return;
        }
        return res.Success("Deleted successfully");
    }

    public async list(req: express.Request, res: express.Response) {
        let qp = req.query;
        let perPage: any = Number(qp.perPage) > 0 ? Number(qp.perPage) : 20;
        let pageNo: any = Number(qp.pageNo) > 0 ? Number(qp.pageNo) - 1 : 0;
        let order: Array<any> = [];
        if (req.query.orderBy && req.query.order) {
            order.push([
                req.query.orderBy as string,
                req.query.order as string,
            ]);
        } else {
            order.push(["createdAt", "DESC"]);
        }

        const where: any = {};

        where["shopId"] = req.auth.id;

        if (qp.keyword) {
            where["name"] = { [Op.like]: "%" + qp.keyword + "%" };
        }

        if (qp.quantity) {
            where["quantity"] = { [Op.lte]: Number(qp.quantity) };
        }

        if (qp.type) {
            where["type"] = { [Op.eq]: qp.type };
        }

        if (qp.brand) {
            where["brand"] = { [Op.eq]: qp.brand };
        }

        if (qp.size) {
            where["size"] = { [Op.eq]: qp.size };
        }

        const data = await Product.findAndCountAll({
            where,
            include: {
                model: Shop,
                attributes: {
                    exclude: ["password", "fcmToken"],
                },
            },
            distinct: true,
            order,
            offset: perPage * pageNo,
            limit: perPage,
        }).catch((e) => {
            console.log(e);
            return res.Error("Error in fetching list");
        });

        if (qp.hasOwnProperty("pageNo")) {
            return res.Success("list", paging(data, pageNo, perPage));
        } else {
            return res.Success("list", data);
        }
    }

    public async updateQuantity(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            quantity: Joi.string().required(),
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const data: any = await Product.update(
            { quantity: req.body.quantity },
            { where: { id: req.body.id, shopId: req.auth.id } }
        );

        if (data == 0) {
            res.Error("Record not Found");
            return;
        }

        const updateddata: Product = await Product.findOne({
            where: { id: req.body.id, shopId: req.auth.id },
        });

        return res.Success("Quantity updated successfully", updateddata);
    }

    public async detail(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const where: any = {
            id: Number(req.body.id),
            shopId: Number(req.auth.id),
        };

        const product = await Product.findOne({
            where,
        });

        if (product === null) {
            res.Error("data not found");
            return;
        }

        res.Success("Product Details", product);
    }
}
