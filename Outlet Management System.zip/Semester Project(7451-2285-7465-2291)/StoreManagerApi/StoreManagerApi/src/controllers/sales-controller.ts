import express from "express";
import Joi, { ValidationError } from "joi";
import { sequelize } from "../configs/connection";
import { Product } from "../models/product";
import { Op } from "sequelize";
import { Shop } from "../models/shop";
import { paging } from "../helpers/helper";
import moment from "moment";
import { ShopSale } from "../models/shop-sale";

export class SalesController {
    private static instance: SalesController | null = null;

    private constructor() {}

    static init(): SalesController {
        if (this.instance == null) {
            this.instance = new SalesController();
        }

        return this.instance;
    }

    public async list(req: express.Request, res: express.Response) {
        let qp = req.query;
        let perPage: any = Number(qp.perPage) > 0 ? Number(qp.perPage) : 20;
        let pageNo: any = Number(qp.page) > 0 ? Number(qp.page) - 1 : 0;
        let order: Array<any> = [];
        if (req.query.orderBy && req.query.order) {
            order.push([
                req.query.orderBy as string,
                req.query.order as string,
            ]);
        } else {
            order.push(["createdAt", "DESC"]);
        }

        const where: any = {};

        where["shopId"] = req.auth.id;

        if (qp.keyword) {
            where["title"] = { [Op.like]: "%" + qp.keyword + "%" };
        }

        if (qp?.duration) {
            if (qp.duration == "day") {
                let date = new Date();
                where["createdAt"] = { [Op.eq]: date };
            } else if (qp.duration == "week") {
                const startOfWeek = new Date();
                startOfWeek.setDate(
                    startOfWeek.getDate() - startOfWeek.getDay()
                );
                where["createdAt"] = {
                    [Op.between]: [startOfWeek, new Date()],
                };
            } else if (qp.duration == "month") {
                const startOfMonth = new Date();
                startOfMonth.setDate(1);
                where["createdAt"] = {
                    [Op.between]: [startOfMonth, new Date()],
                };
            } else {
                const startOfYear = new Date(new Date().getFullYear(), 0, 1);
                where["createdAt"] = {
                    [Op.between]: [startOfYear, new Date()],
                };
            }
        }

        const data = await ShopSale.findAndCountAll({
            where,
            distinct: true,
            order,
            offset: perPage * pageNo,
            limit: perPage,
        }).catch((e) => {
            console.log(e);
            return res.Error("Error in fetching list");
        });

        if (qp.hasOwnProperty("page")) {
            return res.Success("list", paging(data, pageNo, perPage));
        } else {
            return res.Success("list", data);
        }
    }

    public async detail(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.query);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const where: any = {
            id: Number(req.query.id),
            shopId: Number(req.auth.id),
        };

        const shopsale = await ShopSale.findOne({
            where,
        });

        if (shopsale === null) {
            res.Error("Data not found");
            return;
        }

        res.Success("Individual Sale Details", shopsale);
    }
}
