import express from "express";
import Joi, { ValidationError } from "joi";
import { Shop } from "../models/shop";

export class ShopController {
    private static instance: ShopController | null = null;

    private constructor() {}

    static init(): ShopController {
        if (this.instance == null) {
            this.instance = new ShopController();
        }

        return this.instance;
    }

    public async update(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
            name: Joi.string().optional(),
            address: Joi.string().optional().allow(""),
            phoneNumber: Joi.string().optional().allow(""),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const shop: Shop = await Shop.findByPk(req.body.id);

        if (!shop) {
            res.Error("Shop with this id does not exist.");
            return;
        }

        const shopData = {
            ...req.body,
            updatedAt: new Date(),
        };

        try {
            const instance = await Shop.update(shopData, {
                where: { id: req.body.id },
            });

            if (instance) {
                const updatedShop: Shop | null = await Shop.findByPk(
                    req.body.id
                );
                return res.Success("Updated successfully", updatedShop);
            } else {
                return res.Error("error in updating record");
            }
        } catch (e: any) {
            (global as any).log.error(e);
            return res.Error("error in updating record");
        }
    }
}
