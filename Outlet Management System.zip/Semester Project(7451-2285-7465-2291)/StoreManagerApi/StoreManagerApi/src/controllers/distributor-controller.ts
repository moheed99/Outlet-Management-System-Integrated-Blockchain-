import express from "express";
import Joi, { ValidationError } from "joi";
import { sequelize } from "../configs/connection";
import { Product } from "../models/product";
import { Op } from "sequelize";
import { Shop } from "../models/shop";
import { paging } from "../helpers/helper";
import { Distributor } from "../models/distributor";
import { model } from "mongoose";
import { DistributorPayment } from "../models/distributor-payment";
import { ShopExpense } from "../models/shop-expense";

export class DistributorController {
    private static instance: DistributorController | null = null;

    private constructor() {}

    static init(): DistributorController {
        if (this.instance == null) {
            this.instance = new DistributorController();
        }

        return this.instance;
    }

    public async add(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            balance: Joi.number().required(),
            email: Joi.string().email().optional(),
            address: Joi.string().optional(),
            name: Joi.string().required(),
            type: Joi.string().required(),
            phoneNumber: Joi.string().required(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const checkDistributor: Distributor = await Distributor.findOne({
            where: {
                name: req.body.name,
                phoneNumber: req.body.size,
                type: req.body.type,
                shopId: req.auth.id,
            },
        });

        if (checkDistributor != null) {
            res.Error("Distributor already added");
            return;
        }

        const distributorData = {
            name: req.body.name,
            shopId: req.auth.id,
            balance: req.body.quantity,
            type: req.body.brand,
            email: req?.body?.email ? req?.body?.email : "",
            address: req?.body?.address ? req?.body?.address : null,
            phoneNumber: req.body.phoneNumber,
            createdAt: new Date(),
            updatedAt: new Date(),
        };

        const transaction = await sequelize.transaction();
        try {
            const instance = await Distributor.create(distributorData, {
                transaction,
            });

            await transaction.commit();

            res.Success("Added Successfully");
        } catch (e: any) {
            await transaction.rollback();
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }

    public async update(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
            balance: Joi.number().required(),
            email: Joi.string().email().optional(),
            address: Joi.string().optional(),
            name: Joi.string().required(),
            type: Joi.string().required(),
            phoneNumber: Joi.string().required(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const distributor: Distributor = await Distributor.findByPk(
            req.body.id
        );

        if (!distributor) {
            res.Error("Distributor with this id does not exist");
            return;
        }

        const distributorData = {
            ...req.body,
            shopId: req.auth.id,
            updatedAt: new Date(),
        };

        try {
            const instance = await Distributor.update(distributorData, {
                where: { id: req.body.id, shopId: req.auth.id },
            });

            res.Success("Updated Successfully");
        } catch (e: any) {
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }

    public async delete(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const result = await Distributor.destroy({
            where: { id: req.body.id, shopId: req.auth.id },
        });

        if (result == 0) {
            res.Error("Record not Found");
            return;
        }
        return res.Success("Deleted successfully");
    }

    public async list(req: express.Request, res: express.Response) {
        let qp = req.query;
        let perPage: any = Number(qp.perPage) > 0 ? Number(qp.perPage) : 20;
        let pageNo: any = Number(qp.page) > 0 ? Number(qp.page) - 1 : 0;
        let order: Array<any> = [];
        if (req.query.orderBy && req.query.order) {
            order.push([
                req.query.orderBy as string,
                req.query.order as string,
            ]);
        } else {
            order.push(["createdAt", "DESC"]);
        }

        const where: any = {};

        where["shopId"] = req.auth.id;

        if (qp.keyword) {
            where["name"] = { [Op.like]: "%" + qp.keyword + "%" };
        }

        if (qp.balance) {
            if (Number(qp.balance) == 0) {
                where["balance"] = { [Op.eq]: Number(qp.balance) };
            } else {
                where["balance"] = { [Op.gte]: Number(qp.balance) };
            }
        }

        if (qp.type) {
            where["type"] = { [Op.eq]: qp.type };
        }

        const data = await Distributor.findAndCountAll({
            where,
            distinct: true,
            order,
            offset: perPage * pageNo,
            limit: perPage,
        }).catch((e) => {
            console.log(e);
            return res.Error("Error in fetching list");
        });

        if (qp.hasOwnProperty("page")) {
            return res.Success("list", paging(data, pageNo, perPage));
        } else {
            return res.Success("list", data);
        }
    }

    public async updateBalance(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            paidAmount: Joi.string().required(),
            id: Joi.number().required(),
            pendingAmount: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const where: any = {
            id: Number(req.body.id),
            shopId: Number(req.auth.id),
        };

        const distributor: Distributor = await Distributor.findOne({ where });

        if (!distributor) {
            res.Error("Distributor not exist");
            return;
        }

        let balance = Number(distributor.balance);

        if (Number(req?.body?.pendingAmount) > 0) {
            balance = balance + Number(req?.body?.pendingAmount);
        }

        if (Number(req.body.paidAmount) > 0) {
            balance = balance - Number(req.body.paidAmount);
        }

        const data: any = await Distributor.update(
            { balance: balance },
            { where: { id: req.body.id, shopId: req.auth.id } }
        );

        if (data == 0) {
            res.Error("Record not Found");
            return;
        }

        const distributorPaymentData = {
            distributorId: req.body.id,
            shopId: req.auth.id,
            amountPaid:
                Number(req.body.paidAmount) > 0
                    ? req.body.paidAmount
                    : -req?.body?.pendingAmount,
            createdAt: new Date(),
            updatedAt: new Date(),
        };

        const distributorPayment: DistributorPayment =
            await DistributorPayment.create(distributorPaymentData);

        if (Number(req.body.paidAmount) > 0) {
            const shopExpenseData = {
                title: "Distributor Payment",
                description: `This amount is paid to distributor ${distributor.name}`,
                shopId: req.auth.id,
                amount: req.body.paidAmount,
                createdAt: new Date(),
                updatedAt: new Date(),
            };

            const shopExpense: ShopExpense = await ShopExpense.create(
                shopExpenseData
            );
        }

        const updateddata: Distributor = await Distributor.findOne({
            attributes: {
                include: [
                    [
                        sequelize.literal(`(
                        SELECT * FROM DistributorPayment 
                        WHERE DistributorPayment.distributorId = Distributor.id
                        AND DistributorPayment.shopId = Distributor.shopId
                    )`),
                        "distributorPayments",
                    ],
                ],
            },
            where: { id: req.body.id, shopId: req.auth.id },
        });

        return res.Success("Balance updated successfully", updateddata);
    }

    public async detail(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            id: Joi.number().required(),
        });
        const { error, value } = schema.validate(req.body);

        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const where: any = {
            id: Number(req.body.id),
            shopId: Number(req.auth.id),
        };

        const distributor = await Distributor.findOne({
            attributes: {
                include: [
                    [
                        sequelize.literal(`(
                        SELECT * FROM DistributorPayment 
                        WHERE DistributorPayment.distributorId = Distributor.id
                        AND DistributorPayment.shopId = Distributor.shopId
                    )`),
                        "distributorPayments",
                    ],
                ],
            },
            where,
        });

        if (distributor === null) {
            res.Error("data not found");
            return;
        }

        res.Success("Distributor Details", distributor);
    }
}
