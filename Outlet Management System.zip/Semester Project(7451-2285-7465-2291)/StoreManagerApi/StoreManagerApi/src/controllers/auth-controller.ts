import express from "express";
import { Shop } from "../models/shop";
import Joi, { ValidationError } from "joi";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { StatusEnum } from "../constants/enums";
import moment from "moment";
import { sequelize } from "../configs/connection";
import { smtptransporter } from "../bootstrap/app.bootstrap";
import { VerificationCode } from "../models/verification-code";

export class AuthController {
    private static instance: AuthController | null = null;

    private constructor() {}

    static init(): AuthController {
        if (this.instance == null) {
            this.instance = new AuthController();
        }

        return this.instance;
    }

    public async login(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            email: Joi.string().required(),
            password: Joi.string().required(),
            fcmToken: Joi.optional().allow(""),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }
        let shop: Shop;

        shop = await Shop.findOne({
            where: { email: req.body.email },
            attributes: {
                exclude: ["token", "fcmToken"],
            },
        });

        if (shop === null) {
            res.Error("Invalid Email/password");
            return;
        }

        if (shop.emailVerifiedAt === null) {
            res.Error("Email not verified");
            return;
        }

        if (shop.status != StatusEnum.Active) {
            return res.Error("Your account has been disabled");
        }

        if (bcrypt.compareSync(req.body.password, shop.password)) {
            shop.token = "";
            const secret = process.env.ACCESS_SECRET
                ? process.env.ACCESS_SECRET
                : "";
            const token = jwt.sign(shop.toJSON(), secret, {
                expiresIn: 86400 * 15,
            });

            shop.token = token;
            shop.fcmToken = req.body?.fcmToken ? req.body?.fcmToken : null;

            await Shop.update(
                { fcmToken: shop.fcmToken },
                { where: { id: shop.id } }
            );

            res.Success("Login Successful", shop);

            return;
        } else {
            return res.Error("Invalid Username/password");
        }
    }

    public async register(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            password: Joi.string().required(),
            //confirmPassword: Joi.ref("password"),
            email: Joi.string().email().required(),
            name: Joi.string().required(),
            address: Joi.string().optional(),
            phoneNumber: Joi.string().required(),
        });

        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const checkEmail: Shop = await Shop.findOne({
            where: { email: req.body.email },
        });

        if (checkEmail != null) {
            res.Error("Email already taken");
            return;
        }

        const shopData = {
            name: req.body.name,
            address: req?.body?.address ? req.body?.address : null,
            email: req.body.email,
            password: bcrypt.hashSync(req.body.password, 5),
            phoneNumber: req.body.phoneNumber,
            createdAt: new Date(),
            updatedAt: new Date(),
            emailVerifiedAt: new Date(),
        };

        const transaction = await sequelize.transaction();
        try {
            const instance = await Shop.create(shopData, { transaction });

            await transaction.commit();

            res.Success("Register Successfully");
        } catch (e: any) {
            await transaction.rollback();
            console.log(e);
            return res.Error("Something Went Wrong");
        }
    }

    async forgotPassword(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            email: Joi.string().required(),
        });
        const { error, value } = schema.validate(req.body);
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        const shop: any = await Shop.findOne({
            where: { email: req.body.email },
        });

        if (shop === null) {
            res.Error("Email not register");
            return;
        }

        let verificationCode = await VerificationCode.findOne({
            where: { shopId: shop.id },
        });

        let code = Math.floor(100000 + Math.random() * 900000);
        let expiry = moment().add(10, "minutes");

        if (verificationCode) {
            await VerificationCode.update(
                {
                    code: code,
                    expiryDate: new Date(new Date().getTime() + 10 * 60000),
                },
                { where: { id: verificationCode.id } }
            );
        } else {
            let obj: any = {
                code: code,
                expiryDate: new Date(new Date().getTime() + 10 * 60000),
                shopId: shop.id,
                createdAt: new Date(),
                updatedAt: new Date(),
            };

            await VerificationCode.create(obj);
        }

        var mailOptions = {
            from: process.env.MAIL_FROM_ADDRESS,
            to: shop.email,
            subject: "Email Verification",
            html: `<div style="width:500px; border: 1px solid black; padding-left:20px;">
                    <h1> Dear,  ${shop.name},</h1> <hr />
                    <p> Your reset password code is ${code}</p>
                    <p> Thank You </p>
                    </div>`,
        };

        if (shop.email) {
            smtptransporter.sendMail(
                mailOptions,
                function (err: any, info: any) {
                    if (err) console.log(err);
                    console.log(info);
                }
            );
            res.Success("Verification code sent successfully");
        }
    }

    async resetPassword(req: express.Request, res: express.Response) {
        const schema = Joi.object().keys({
            code: Joi.number().required(),
            password: Joi.string().min(3).required(),
            //password_confirmation: Joi.ref("password"),
        });
        const { error, value } = schema.validate(req.body, {
            allowUnknown: false,
        });
        if (error instanceof ValidationError) {
            res.Error(error.details[0].message);
            return;
        }

        let verificationCode = await VerificationCode.findOne({
            where: { code: req.body.code },
        });

        if (verificationCode == null) {
            res.Error("Reset Code Expired or Used");
            return;
        }

        if (verificationCode?.shopId) {
            await Shop.update(
                {
                    password: bcrypt.hashSync(req.body.password, 8),
                },
                {
                    where: { id: verificationCode.shopId },
                }
            );

            let shop = await Shop.findOne({
                where: { id: verificationCode.shopId },
            });

            if (shop === null) {
                res.Error("No Data Found");
            }

            shop.token = "";
            const secret = process.env.ACCESS_SECRET
                ? process.env.ACCESS_SECRET
                : "";
            const token = jwt.sign(shop.toJSON(), secret, {
                expiresIn: 86400 * 15,
            });

            shop.token = token;
            shop.emailVerifiedAt = new Date();

            let rec = {
                token: token,
            };

            await Shop.update(rec, { where: { id: shop.id } });
            return res.Success("Password Successfully Changed", shop);
        } else {
            res.Error("Something Went Wrong");
        }
    }

    public async logout(req: express.Request, res: express.Response) {
        await Shop.update(
            { token: null, fcmToken: null },
            { where: { id: req.auth.id } }
        );
        return res.Success("Log Out Successfully");
    }
}
