import express, { NextFunction } from "express";
import { Middleware, callback } from "./middleware";
import jwt from "jsonwebtoken";

export class AuthMiddleware extends Middleware {
    constructor(app: express.Application) {
        super(app);
    }

    handle(req: express.Request, res: express.Response, next: callback) {
        const authHeader = req.headers["authorization"];
        const token = authHeader && authHeader.split(" ")[1];
        if (token == null) {
            return res.Error("You are not authorized");
        }
        jwt.verify(
            token,
            process.env.ACCESS_SECRET as string,
            (err: any, user: any) => {
                if (err) {
                    return res.Error("You are not authorized");
                }
                req.auth = user;
                next();
            }
        );
    }
}
