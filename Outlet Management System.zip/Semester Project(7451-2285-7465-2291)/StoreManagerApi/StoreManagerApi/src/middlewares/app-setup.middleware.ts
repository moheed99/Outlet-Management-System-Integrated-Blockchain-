import express, { NextFunction } from 'express';
import cors from 'cors';
import * as bodyparser from 'body-parser';
import * as winston from 'winston';
import * as expressWinston from 'express-winston';
import { Middleware } from './middleware';

export class AppSetupMiddleware extends Middleware {
    app: express.Application;

    constructor(app: express.Application) {
        super(app);
        this.app = app;
    }

    handle() {
        this.app.use(this.responseMiddleware);
        // here we are adding middleware to parse all incoming requests as JSON 
        this.app.use(bodyparser.json());
        this.app.use(bodyparser.urlencoded({ extended: false }));

        // here we are adding middleware to allow cross-origin requests
        this.app.use(cors());
    }

    responseMiddleware(req: express.Request, res: express.Response, next: any) {
        res.Success = (message: string, data?: any, respCode?: number) => {
            respCode = respCode ? respCode : 200
            res.status(respCode)
                .json({
                    success: true,
                    message,
                    data
                })
        };

        res.Error = (message: string, data?: any, respCode?: number) => {
            respCode = respCode ? respCode : 200
            res.status(respCode)
                .json({
                    success: false,
                    message,
                    data
                })
        };

        next();
    }

    httpLogs() {
        // here we are configuring the expressWinston logging middleware,
        // which will automatically log all HTTP requests handled by Express.js
	/*
        this.app.use(expressWinston.logger({
            transports: [
                new winston.transports.Console()
            ],
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.json()
            )
        }));

        // here we are configuring the expressWinston error-logging middleware,
        // which doesn't *handle* errors per se, but does *log* them
        this.app.use(expressWinston.errorLogger({
            transports: [
                new winston.transports.Console()
            ],
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.json()
            )
        }));
	*/
    }
}
