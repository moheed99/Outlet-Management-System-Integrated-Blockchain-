export enum ProductTypeEnum {
    Electric = "Electric",
    Sanitary = "Sanitary",
    Paint = "Paint",
    Hardware = "Hardware",
    Mobile = "Mobile",
    Other = "Other",
}

export enum SellOrderStatusEnum {
    Delivered = "Delivered",
    Pending = "Pending",
}

export enum StatusEnum {
    Active = "Active",
    Inactive = "Inactive",
}

export enum SellOrderPaymentStatusEnum {
    Paid = "Paid",
    Pending = "Pending",
}

export enum BuyOrderStatusEnum {
    Placed = "Placed",
    Complete = "Complete",
}

export enum DistributorTypeEnum {
    Electric = "Electric",
    Sanitary = "Sanitary",
    Paint = "Paint",
    Hardware = "Hardware",
    Mobile = "Mobile",
    Other = "Other",
}
