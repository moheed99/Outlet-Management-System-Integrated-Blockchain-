import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";
import { BuyOrderStatusEnum } from "../constants/enums";
import { enumKeys } from "../helpers/helper";

export class BuyOrder extends Model<
    InferAttributes<BuyOrder>,
    InferCreationAttributes<BuyOrder>
> {
    id: number;
    shopId: number;
    distributorId: number;
    orderTotalAmount: number;
    status: BuyOrderStatusEnum;
    createdAt?: Date;
    updatedAt?: Date;
}

BuyOrder.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        shopId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        distributorId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        orderTotalAmount: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        status: {
            type: DataTypes.ENUM(...enumKeys(BuyOrderStatusEnum)),
            defaultValue: BuyOrderStatusEnum.Placed,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "buy_orders",
    }
);
