import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";

export class DistributorPayment extends Model<
    InferAttributes<DistributorPayment>,
    InferCreationAttributes<DistributorPayment>
> {
    id: number;
    shopId: number;
    distributorId: number;
    amountPaid: number;
    createdAt?: Date;
    updatedAt?: Date;
}

DistributorPayment.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        shopId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        distributorId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        amountPaid: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "distributor_payments",
    }
);
