import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";
import { BuyOrderStatusEnum } from "../constants/enums";
import { enumKeys } from "../helpers/helper";
import { Decimal128 } from "mongoose";

export class SellOrderProduct extends Model<
    InferAttributes<SellOrderProduct>,
    InferCreationAttributes<SellOrderProduct>
> {
    id: number;
    sellOrderId: number;
    productId: number;
    quantityOrder: number;
    productPrice: number;
    productDiscountedPrice: number;
    createdAt?: Date;
    updatedAt?: Date;
}

SellOrderProduct.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        sellOrderId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        productId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        quantityOrder: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        productPrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        productDiscountedPrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "sell_order_products",
    }
);
