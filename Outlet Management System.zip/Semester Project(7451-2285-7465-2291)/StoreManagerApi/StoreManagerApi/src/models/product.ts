import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";
import { ProductTypeEnum } from "../constants/enums";
import { enumKeys } from "../helpers/helper";
import { Decimal128 } from "mongoose";
import { BuyOrderProduct } from "./buy-order-product";
import { SellOrderProduct } from "./sell-order-product";

export class Product extends Model<
    InferAttributes<Product>,
    InferCreationAttributes<Product>
> {
    id: number;
    shopId: number;
    size: string;
    name: string;
    brand: string;
    quantity: number;
    oldPurchasePrice: number;
    newPurchasePrice: number;
    salePrice: number;
    type: ProductTypeEnum;
    createdAt?: Date;
    updatedAt?: Date;
}

Product.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        name: {
            type: DataTypes.STRING(50),
        },
        size: {
            type: DataTypes.STRING(259),
        },
        brand: {
            type: DataTypes.STRING(150),
        },
        shopId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        quantity: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        oldPurchasePrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        newPurchasePrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        salePrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        type: {
            type: DataTypes.ENUM(...enumKeys(ProductTypeEnum)),
            defaultValue: ProductTypeEnum.Other,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "products",
    }
);

Product.hasMany(BuyOrderProduct, {
    foreignKey: "productId",
});

BuyOrderProduct.belongsTo(Product, {
    foreignKey: "productId",
});

Product.hasMany(SellOrderProduct, {
    foreignKey: "productId",
});

SellOrderProduct.belongsTo(Product, {
    foreignKey: "productId",
});
