import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";
import { DistributorTypeEnum } from "../constants/enums";
import { enumKeys } from "../helpers/helper";
import { Decimal128 } from "mongoose";
import { DistributorPayment } from "./distributor-payment";
import { BuyOrder } from "./buy-order";

export class Distributor extends Model<
    InferAttributes<Distributor>,
    InferCreationAttributes<Distributor>
> {
    id: number;
    shopId: number;
    address: string;
    name: string;
    email: string;
    phoneNumber: string;
    balance: number;
    type: DistributorTypeEnum;
    createdAt?: Date;
    updatedAt?: Date;
}

Distributor.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        name: {
            type: DataTypes.STRING(50),
        },
        address: {
            type: DataTypes.STRING(259),
            allowNull: true,
        },
        phoneNumber: {
            type: DataTypes.STRING(15),
        },
        email: {
            type: DataTypes.STRING(150),
        },
        shopId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        balance: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        type: {
            type: DataTypes.ENUM(...enumKeys(DistributorTypeEnum)),
            defaultValue: DistributorTypeEnum.Other,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "distributors",
    }
);

Distributor.hasMany(DistributorPayment, {
    foreignKey: "distributorId",
});

DistributorPayment.belongsTo(Distributor, {
    foreignKey: "distributorId",
});

Distributor.hasMany(BuyOrder, {
    foreignKey: "distributorId",
});

BuyOrder.belongsTo(Distributor, {
    foreignKey: "distributorId",
});
