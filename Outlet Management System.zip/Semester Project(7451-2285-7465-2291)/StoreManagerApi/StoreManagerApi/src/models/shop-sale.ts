import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";
import { DistributorTypeEnum, StatusEnum } from "../constants/enums";
import { enumKeys } from "../helpers/helper";
import { Decimal128 } from "mongoose";

export class ShopSale extends Model<
    InferAttributes<ShopSale>,
    InferCreationAttributes<ShopSale>
> {
    id: number;
    shopId: number;
    sellOrderId: number;
    title: string;
    description: string;
    amount: number;
    createdAt?: Date;
    updatedAt?: Date;
}

ShopSale.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        title: {
            type: DataTypes.STRING(50),
        },
        description: {
            type: DataTypes.STRING(259),
            allowNull: true,
        },
        shopId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        sellOrderId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        amount: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "shop-sales",
    }
);
