import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
    ForeignKey,
} from "sequelize";
import { sequelize } from "../configs/connection";
import { StatusEnum } from "../constants/enums";
import { enumKeys } from "../helpers/helper";
import { Decimal128 } from "mongoose";
import { Product } from "./product";
import { Distributor } from "./distributor";
import { DistributorPayment } from "./distributor-payment";
import { BuyOrder } from "./buy-order";
import { SellOrder } from "./sell-order";
import { ShopSale } from "./shop-sale";
import { ShopExpense } from "./shop-expense";

export class Shop extends Model<
    InferAttributes<Shop>,
    InferCreationAttributes<Shop>
> {
    id: number;
    address: string;
    name: string;
    email: string;
    phoneNumber: string;
    password: string;
    token: string;
    fcmToken: string;
    emailVerifiedAt: Date;
    status: StatusEnum;
    createdAt?: Date;
    updatedAt?: Date;
}

Shop.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        name: {
            type: DataTypes.STRING(50),
        },
        address: {
            type: DataTypes.STRING(259),
            allowNull: true,
        },
        phoneNumber: {
            type: DataTypes.STRING(15),
        },
        email: {
            type: DataTypes.STRING(150),
        },
        password: {
            type: DataTypes.STRING(1000),
        },
        token: {
            type: DataTypes.TEXT("long"),
        },
        fcmToken: {
            type: DataTypes.STRING(1000),
        },
        emailVerifiedAt: {
            type: "TIMESTAMP NULL",
            allowNull: true,
            defaultValue: null,
        },
        status: {
            type: DataTypes.ENUM(...enumKeys(StatusEnum)),
            defaultValue: StatusEnum.Active,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "shops",
    }
);

Shop.hasMany(Product, {
    foreignKey: "shopId",
});

Product.belongsTo(Shop, {
    foreignKey: "shopId",
});

Shop.hasMany(Distributor, {
    foreignKey: "shopId",
});

Distributor.belongsTo(Shop, {
    foreignKey: "shopId",
});

Shop.hasMany(DistributorPayment, {
    foreignKey: "shopId",
});

DistributorPayment.belongsTo(Shop, {
    foreignKey: "shopId",
});

Shop.hasMany(BuyOrder, {
    foreignKey: "shopId",
});

BuyOrder.belongsTo(Shop, {
    foreignKey: "shopId",
});

Shop.hasMany(SellOrder, {
    foreignKey: "shopId",
});

SellOrder.belongsTo(Shop, {
    foreignKey: "shopId",
});

Shop.hasMany(ShopSale, {
    foreignKey: "shopId",
});

ShopSale.belongsTo(Shop, {
    foreignKey: "shopId",
});

Shop.hasMany(ShopExpense, {
    foreignKey: "shopId",
});

ShopExpense.belongsTo(Shop, {
    foreignKey: "shopId",
});
