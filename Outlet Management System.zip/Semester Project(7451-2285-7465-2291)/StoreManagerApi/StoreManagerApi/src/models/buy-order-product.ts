import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
} from "sequelize";
import { sequelize } from "../configs/connection";

export class BuyOrderProduct extends Model<
    InferAttributes<BuyOrderProduct>,
    InferCreationAttributes<BuyOrderProduct>
> {
    id: number;
    buyOrderId: number;
    productId: number;
    quantityOrder: number;
    previousPurchasePrice: number;
    currentPurchasePrice: number;
    createdAt?: Date;
    updatedAt?: Date;
}

BuyOrderProduct.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        buyOrderId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        productId: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        quantityOrder: {
            type: DataTypes.BIGINT.UNSIGNED,
            allowNull: false,
        },
        previousPurchasePrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        currentPurchasePrice: {
            type: DataTypes.DECIMAL(8, 2),
            allowNull: false,
            defaultValue: 0,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        timestamps: false,
        tableName: "buy_order_products",
    }
);
