import {
    Model,
    InferAttributes,
    InferCreationAttributes,
    DataTypes,
} from "sequelize";
import { sequelize } from "../configs/connection";

export class VerificationCode extends Model<
    InferAttributes<VerificationCode>,
    InferCreationAttributes<VerificationCode>
> {
    id: number;
    shopId: number;
    code: number;
    expiryDate: Date;
    createdAt: Date;
    updatedAt: Date;
}

VerificationCode.init(
    {
        id: {
            type: DataTypes.BIGINT.UNSIGNED,
            primaryKey: true,
            autoIncrement: true,
        },
        shopId: {
            type: DataTypes.BIGINT.UNSIGNED,
        },
        code: {
            type: DataTypes.STRING(15),
        },

        expiryDate: {
            type: "TIMESTAMP NULL",
            allowNull: true,
            defaultValue: null,
        },
        createdAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            allowNull: false,
        },
        updatedAt: {
            type: "TIMESTAMP",
            defaultValue: sequelize.literal(
                "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
            ),
            allowNull: false,
        },
    },
    {
        sequelize,
        tableName: "verification_codes",
        timestamps: false,
    }
);
