interface GeneralException {
    code: number;
    errors: any;
}