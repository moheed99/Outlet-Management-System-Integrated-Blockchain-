// src/backend/routes/blockchainRoutes.js
const express = require("express");
const router = express.Router();
const { web3, contract } = require("../blockchain");  // Import web3 and contract

// POST route to add item to blockchain
router.post("/api/addItem", async (req, res) => {
    const { name, price } = req.body;
    try {
        const accounts = await web3.eth.getAccounts();  // Get MetaMask account
        // Send the transaction to record the item on the blockchain
        await contract.methods.recordTransaction(Date.now(), name, price, accounts[0]).send({ from: accounts[0] });

        res.status(200).send({ message: "Item added to blockchain!" });
    } catch (error) {
        console.error("Error adding item:", error);
        res.status(500).send({ error: error.message || "Failed to add item to blockchain." });
    }
});

// GET route to fetch item from blockchain
router.get("/api/getItem/:id", async (req, res) => {
    const { id } = req.params;  // Get item ID from frontend
    try {
        const transactions = await contract.methods.getTransactions().call();  // Fetch all transactions from the contract
        const foundItem = transactions.find(tx => tx.id == id);  // Find the item by ID
        if (foundItem) {
            res.status(200).send(foundItem);  // Return item details
        } else {
            res.status(404).send({ message: "Item not found" });
        }
    } catch (error) {
        console.error("Error fetching item:", error);
        res.status(500).send({ error: error.message || "Failed to fetch item from blockchain." });
    }
});

module.exports = router;
