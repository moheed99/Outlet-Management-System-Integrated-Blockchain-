//import { UserController } from "../controllers/user-controller";
import express, { Router } from "express";
import { RoutesConfig } from "./routes.config";
import { AuthMiddleware } from "../middlewares/auth.middleware";
import { ShopController } from "../controllers/shop-controller";
import { ProductController } from "../controllers/product-controller";
import { DistributorController } from "../controllers/distributor-controller";
import { ExpenseController } from "../controllers/expense-controller";
import { SalesController } from "../controllers/sales-controller";

export class ShopRoutes extends RoutesConfig {
    route: Router;
    constructor(app: express.Application) {
        super(app, "ShopRoutes");
    }

    configureRoutes() {
        this.route = express.Router();

        this.profileRoutes();
        this.expenseRoutes();
        this.salesRoutes();
        this.productsRoutes();
        this.distributorsRoutes();
        this.saleOrdersRoutes();
        this.buyOrdersRoutes();

        this.app.use("/api/shop", new AuthMiddleware(this.app).handle);
        this.app.use("/api/shop", this.route);

        return this.app;
    }

    profileRoutes() {
        const route = express.Router();
        const controller = ShopController.init();

        route.post("/update", controller.update);

        this.route.use("/profile", route);
    }

    expenseRoutes() {
        const route = express.Router();
        const controller = ExpenseController.init();

        route.get("/list", controller.list);
        route.post("/save", controller.add);
        route.post("/update", controller.update);
        route.get("/detail", controller.detail);
        route.post("/delete", controller.delete);

        this.route.use("/expense", route);
    }

    salesRoutes() {
        const route = express.Router();
        const controller = SalesController.init();

        route.get("/list", controller.list);
        route.get("/detail", controller.detail);

        this.route.use("/sale", route);
    }

    productsRoutes() {
        const route = express.Router();
        const controller = ProductController.init();

        route.get("/list", controller.list);
        route.post("/save", controller.add);
        route.post("/update", controller.update);
        route.post("/update-quantity", controller.updateQuantity);
        route.get("/detail", controller.detail);
        route.post("/delete", controller.delete);

        this.route.use("/product", route);
    }

    distributorsRoutes() {
        const route = express.Router();
        const controller = DistributorController.init();

        route.get("/list", controller.list);
        route.post("/save", controller.add);
        route.post("/update", controller.update);
        route.post("/update-balance", controller.updateBalance);
        route.get("/detail", controller.detail);
        route.post("/delete", controller.delete);

        this.route.use("/distributor", route);
    }

    saleOrdersRoutes() {}

    buyOrdersRoutes() {}
}
