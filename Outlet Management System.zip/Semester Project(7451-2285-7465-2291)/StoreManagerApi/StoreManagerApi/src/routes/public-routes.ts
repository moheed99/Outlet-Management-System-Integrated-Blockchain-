import express, { Router } from "express";
import { AuthController } from "../controllers/auth-controller";
import { RoutesConfig } from "./routes.config";

export class PublicRoutes extends RoutesConfig {
    route: Router;
    constructor(app: express.Application) {
        super(app, "PublicRoutes");
    }

    configureRoutes() {
        this.route = express.Router();

        this.authRoutes();

        this.app.use("/api/public", this.route);

        return this.app;
    }

    authRoutes() {
        const route = express.Router();
        const controller = AuthController.init();

        route.post("/register", controller.register);
        route.post("/forgot-password", controller.forgotPassword);
        route.post("/reset-password", controller.resetPassword);
        route.post("/login", controller.login);

        this.route.use("/", route);
    }
}
