import exp from "constants";
import path from "path";

export class Helper {}

export const isGeneralException = (x: any): x is GeneralException => {
    return typeof x.code === "number";
};

export function enumToArray(data: any) {
    const arrayObjects = [];
    for (const [propertyKey, propertyValue] of Object.entries(data)) {
        arrayObjects.push({ id: propertyValue, name: propertyKey });
    }

    return arrayObjects;
}

export function enumKeys(data: any): Array<string> {
    const arrayObjects: Array<string> = [];
    for (const [propertyKey, propertyValue] of Object.entries(data)) {
        arrayObjects.push(propertyValue.toString());
    }

    return arrayObjects;
}

export const paging = (results: any, page: number, perPage: number) => {
    const { count: totalItems, rows: data } = results;
    const currentPage = page ? +page : 1;
    const totalPages = Math.ceil(totalItems / perPage);
    return { totalItems, data, totalPages, currentPage, perPage };
};

export const filePath = (fPath: any) => {
    const storagePath = path.resolve(__dirname, "..", "..", "..", fPath);
    // console.log('path------From helper', storagePath);
    return storagePath;
};

export const sendSms = (phone: any, message: any) => {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const client = require("twilio")(accountSid, authToken);

    client.messages
        .create({
            body: message,
            //from: '+123456789',
            messagingServiceSid: "MG2703f34db10da60ad8e92ded57db8849",
            to: phone,
        })
        .then((message: any) => console.log(message.sid));
};
