import express from 'express';
 
export class Command {
    app: express.Application
    constructor() {
        
    }
}