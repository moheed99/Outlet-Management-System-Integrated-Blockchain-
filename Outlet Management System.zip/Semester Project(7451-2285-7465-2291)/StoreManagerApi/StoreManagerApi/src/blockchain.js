// src/blockchain.js
import Web3 from "web3";

// Web3 and contract initialization
let web3;
let contract;

if (window.ethereum) {
    web3 = new Web3(window.ethereum);
    window.ethereum.request({ method: "eth_requestAccounts" }); // Request MetaMask account access

    // Dynamically fetch ABI from the public folder
    fetch("/OutletManagement.json") // Fetch ABI from public folder
        .then((response) => response.json())
        .then((data) => {
            const contractAddress =
                "0x4D8118c5C0C017daCb6B831d651cC7addE67B226"; // Your deployed contract address
            contract = new web3.eth.Contract(data.abi, contractAddress); // Initialize the contract with ABI
        })
        .catch((error) => {
            console.error("Error loading contract ABI:", error);
        });
} else {
    console.error("MetaMask not found. Please install it!");
}

export { web3, contract };
