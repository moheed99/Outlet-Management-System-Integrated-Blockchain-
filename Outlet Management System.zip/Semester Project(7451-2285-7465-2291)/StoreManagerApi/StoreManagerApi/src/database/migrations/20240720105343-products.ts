"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";
import { ProductTypeEnum } from "../../constants/enums";
import { enumKeys } from "../../helpers/helper";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("products", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            name: {
                type: DataTypes.STRING(50),
            },
            size: {
                type: DataTypes.STRING(259),
            },
            brand: {
                type: DataTypes.STRING(150),
            },
            shopId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            quantity: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            oldPurchasePrice: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            newPurchasePrice: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            salePrice: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            type: {
                type: DataTypes.ENUM(...enumKeys(ProductTypeEnum)),
                defaultValue: ProductTypeEnum.Other,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("products");
    },
};
