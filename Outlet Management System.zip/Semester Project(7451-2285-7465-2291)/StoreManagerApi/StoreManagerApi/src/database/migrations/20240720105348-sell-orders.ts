"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";
import {
    SellOrderPaymentStatusEnum,
    SellOrderStatusEnum,
} from "../../constants/enums";
import { enumKeys } from "../../helpers/helper";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("sell_orders", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            shopId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            customerName: {
                type: DataTypes.STRING(50),
                allowNull: true,
            },
            customerAddress: {
                type: DataTypes.STRING(259),
                allowNull: true,
            },
            customerPhoneNumber: {
                type: DataTypes.STRING(15),
                allowNull: true,
            },
            customerEmail: {
                type: DataTypes.STRING(150),
                allowNull: true,
            },
            totalBill: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            totalDiscountedBill: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            amountPaid: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            amountPending: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            specialDiscount: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            status: {
                type: DataTypes.ENUM(...enumKeys(SellOrderStatusEnum)),
                defaultValue: SellOrderStatusEnum.Pending,
            },
            paymentStatus: {
                type: DataTypes.ENUM(...enumKeys(SellOrderPaymentStatusEnum)),
                defaultValue: SellOrderPaymentStatusEnum.Pending,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("sell_orders");
    },
};
