"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";
import { StatusEnum } from "../../constants/enums";
import { enumKeys } from "../../helpers/helper";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("sell_order_products", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            sellOrderId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            productId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            quantityOrder: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            productPrice: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            productDiscountedPrice: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("sell_order_products");
    },
};
