"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("verification_codes", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            shopId: {
                type: DataTypes.BIGINT.UNSIGNED,
            },
            code: {
                type: DataTypes.STRING(15),
            },

            expiryDate: {
                type: "TIMESTAMP NULL",
                allowNull: true,
                defaultValue: null,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("verification_codes");
    },
};
