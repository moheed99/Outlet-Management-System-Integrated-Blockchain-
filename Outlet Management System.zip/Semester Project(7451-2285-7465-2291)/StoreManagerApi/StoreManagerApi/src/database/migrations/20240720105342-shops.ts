"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";
import { StatusEnum } from "../../constants/enums";
import { enumKeys } from "../../helpers/helper";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("shops", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            name: {
                type: DataTypes.STRING(50),
            },
            phoneNumber: {
                type: DataTypes.STRING(15),
            },
            email: {
                type: DataTypes.STRING(150),
            },
            password: {
                type: DataTypes.STRING(1000),
            },
            address: {
                type: DataTypes.STRING(259),
                allowNull: true,
            },
            token: {
                type: DataTypes.TEXT("long"),
            },
            fcmToken: {
                type: DataTypes.STRING(1000),
            },
            emailVerifiedAt: {
                type: "TIMESTAMP NULL",
                allowNull: true,
                defaultValue: null,
            },
            status: {
                type: DataTypes.ENUM(...enumKeys(StatusEnum)),
                defaultValue: StatusEnum.Active,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("shops");
    },
};
