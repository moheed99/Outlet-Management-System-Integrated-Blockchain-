"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";
import { BuyOrderStatusEnum } from "../../constants/enums";
import { enumKeys } from "../../helpers/helper";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("buy_orders", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            shopId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            distributorId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            orderTotalAmount: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            status: {
                type: DataTypes.ENUM(...enumKeys(BuyOrderStatusEnum)),
                defaultValue: BuyOrderStatusEnum.Placed,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("buy_orders");
    },
};
