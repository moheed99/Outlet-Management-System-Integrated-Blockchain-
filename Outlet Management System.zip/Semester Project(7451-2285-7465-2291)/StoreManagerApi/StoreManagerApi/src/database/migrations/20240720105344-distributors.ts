"use strict";

import { QueryInterface, DataTypes } from "sequelize";
import Sequelize from "sequelize";
import { DistributorTypeEnum } from "../../constants/enums";
import { enumKeys } from "../../helpers/helper";

module.exports = {
    up: (queryInterface: QueryInterface) => {
        return queryInterface.createTable("distributors", {
            id: {
                type: DataTypes.BIGINT.UNSIGNED,
                primaryKey: true,
                autoIncrement: true,
            },
            name: {
                type: DataTypes.STRING(50),
            },
            address: {
                type: DataTypes.STRING(259),
                allowNull: true,
            },
            phoneNumber: {
                type: DataTypes.STRING(15),
            },
            email: {
                type: DataTypes.STRING(150),
            },
            shopId: {
                type: DataTypes.BIGINT.UNSIGNED,
                allowNull: false,
            },
            balance: {
                type: DataTypes.DECIMAL(8, 2),
                allowNull: false,
                defaultValue: 0,
            },
            type: {
                type: DataTypes.ENUM(...enumKeys(DistributorTypeEnum)),
                defaultValue: DistributorTypeEnum.Other,
            },
            createdAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
                allowNull: false,
            },
            updatedAt: {
                type: "TIMESTAMP",
                defaultValue: Sequelize.literal(
                    "CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
                ),
                allowNull: false,
            },
        });
    },
    down: (queryInterface: QueryInterface, Sequelize: any) => {
        return queryInterface.dropTable("distributors");
    },
};
