"use strict";

import Sequelize, { NOW } from "sequelize";

module.exports = {
    async up(queryInterface: any, Sequelize: any) {
        return queryInterface.bulkInsert("shops", [
            {
                id: 1,
                firstName: "Shop",
                lastName: "One",
                email: "shopone@mail.com",
                phoneNumber: "+923115395283",
                password:
                    "$2a$05$oQyxb1XHx1awGVLwf/7f3emoLV.deo5tyigEeMzRCDjhAOHMbLy5C",
                emailVerifiedAt: new Date(),
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                id: 2,
                firstName: "Shop",
                lastName: "Two",
                email: "shoptwo@mail.com",
                phoneNumber: "+923465030779",
                password:
                    "$2a$05$oQyxb1XHx1awGVLwf/7f3emoLV.deo5tyigEeMzRCDjhAOHMbLy5C",
                emailVerifiedAt: new Date(),
                createdAt: new Date(),
                updatedAt: new Date(),
            },
        ]);
    },

    async down(queryInterface: any, Sequelize: any) {
        await queryInterface.bulkDelete("shops", null, {});
    },
};
