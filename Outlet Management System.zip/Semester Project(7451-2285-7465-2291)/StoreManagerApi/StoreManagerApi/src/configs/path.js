import { dirname } from 'path';

module.exports = dirname(require.main.filename);