import { filePath } from "../helpers/helper";
require("dotenv").config({ path: filePath("") + "/.env" });
const fs = require("fs");

module.exports = {
    development: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        dialect: "mysql",
        logging: false,
        dialectOptions: {
            bigNumberStrings: true,
            useUTC: true, // for reading
        },
        seederStorage: "sequelize",
        timeZone: "UTC",
    },
    test: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        dialect: "mysql",
        logging: false,
        dialectOptions: {
            bigNumberStrings: true,
            useUTC: true, // for reading
        },
        seederStorage: "sequelize",
        timeZone: "UTC",
    },
    production: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        dialect: "mysql",
        logging: false,
        dialectOptions: {
            bigNumberStrings: true,
            useUTC: true, // for reading
            // ssl: {
            //     ca: fs.readFileSync(__dirname + '/mariadb-ca-main.crt')
            // }
        },
        seederStorage: "sequelize",
        timeZone: "UTC",
    },
};
